from pygame import mixer
mixer.init()
mixer.music.load('MP3.mp3')
mixer.music.play()
input('Agora você escuta?')